

function calcular(){
	var formulario = document.getElementById('formulario');

	var peso = parseFloat(formulario.peso.value);

	var altura = parseFloat(formulario.altura.value);

	var imc = peso / (altura * altura) ;

	if (document.formulario.peso.value == "" || document.formulario.peso.value == "0") {
		document.getElementById('p-peso').innerHTML = "Preencha o campo peso!";
		document.formulario.peso.focus();
		return false;
	} if (document.formulario.altura.value == "" || document.formulario.altura.value == "0"){
		document.getElementById('p-altura').innerHTML = "Preencha o campo altura!";
		document.formulario.altura.focus();
		return false;
	} else{
	document.getElementById('resultado').className = 'resultado2';
};

	switch(true){
	case(imc <= 18.5):
		document.getElementById('texto-result').innerHTML = "Seu indice de massa corporal é: " + imc.toFixed(2) + " Você está abaixo do peso ideal";
	break;
	case(imc <= 24.9):
		document.getElementById('texto-result').innerHTML = "Seu indice de massa corporal é: " + imc.toFixed(2) + " Você está no peso ideal";
	break;
	case(imc <= 29.9):
		document.getElementById('texto-result').innerHTML = "Seu indice de massa corporal é: " + imc.toFixed(2) + " Você está levemente acima do peso";
	break;
	case(imc <= 34.9):
		document.getElementById('texto-result').innerHTML = "Seu indice de massa corporal é: " + imc.toFixed(2) + " Você está com obesidade primeiro grau";
	break;
	case(imc <= 39.9):
		document.getElementById('texto-result').innerHTML = "Seu indice de massa corporal é: " + imc.toFixed(2) + " Você está com obesidade segundo grau";
	break;
	case(imc >= 40):
		document.getElementById('texto-result').innerHTML = "Seu indice de massa corporal é: " + imc.toFixed(2) + " Você está com obesidade terceiro grau";
	break;
	default:
		document.getElementById('texto-result').innerHTML = "preencha os campos!";
	break;

	};
};

function voltar(){
	document.getElementById('resultado').className = 'resultado1';
};

function show(){

	if (document.getElementById('menu').className == 'menu') {
		document.getElementById('menu').className = 'menu2';
	}else if (document.getElementById('menu').className == 'menu2') {
		document.getElementById('menu').className = 'menu';
	}
}